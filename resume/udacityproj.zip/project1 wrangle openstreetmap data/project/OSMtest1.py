import xml.etree.cElementTree as ET
import pprint
import re
import csv

lower = re.compile(r'^([a-z]|_)*$')
lower_colon = re.compile(r'^([a-z]|_)*:([a-z]|_)*$')
problemchars = re.compile(r'[=\+/&<>;\'"\?%#$@\,\. \t\r\n]')
zhPattern = re.compile(u'[\u4e00-\u9fa5]+')
digit = re.compile(r'\d+')
addr_colon_div = re.compile(r'addr:(.*)')
road_ = re.compile(u'(.*)路(.*)')


filename = "C:/Users/Errorplayer/Downloads/ww"
outputfile = "C:/Users/Errorplayer/Downloads/output.csv"
def key_type(element, keys):
    #indecation  = True
    '''if element.tag == "tag":
        result1 = lower.search(element.attrib["v"])
        if result1:
            keys["lower"] += 1
            #print (element.attrib["k"])
        else:
            result2 = lower_colon.search(element.attrib["v"])
            if result2:
               keys["lower_colon"] += 1
            else :
                result3 = problemchars.search(element.attrib["v"])
                if result3:
                   keys["problemchars"] += 1
                   #print (element.attrib["v"])
                else:
                    keys["other"] +=1
                    #print ((element.attrib["k"]),"[[]]",(element.attrib["v"]))
        '''
    if element.tag == "tag":
         #ele = []
         #ele.append(element.attrib["k"])
         ##result1 = lower.search(element.attrib["v"])
         #result2 = lower_colon.search(element.attrib["v"])
         #result3 = problemchars.search(element.attrib["v"])
         #if (not (result1 or result2 or result3)):
         #matchObj = digit.search(element.attrib["v"])
         #if matchObj:
         #   print ("v-> ",element.attrib["v"])
         #else:
         #   ele.append(element.attrib["v"])
          #  keys.append(ele)
         #if (element.attrib["k"].find("addr") > -1):
         '''match = colon_div.search( element.attrib["k"])
         if match:
            if  (match.group(1) not in keys.keys()):
                keys[match.group(1)] = 1
            else:
                keys[match.group(1)] +=1'''
         addr_colon_div = re.compile(r'addr:(.*)')
         match = addr_colon_div.search( element.attrib["k"])
         if match:
           if  (match.group(1) =="city"):
             print (update_cityName(element.attrib["v"]))
         
            
    
def update_cityName(name):
   Pattern = re.compile(u'(.*)市(.*)区')
   match = Pattern.search(name)
   if match:
     return (match.group(1)+"市")
   else:
      return (name)             
                   
         
                   
    

def save_file(data, filename):
    # YOUR CODE HERE
    with open(filename,'w',encoding = "gbk") as csvfile:
       spamwriter = csv.writer(csvfile, delimiter="|")
       
       outer_show = []
       for out in range(len(data)):
           inner_show = []
           for inner in range(len(data[out])):
               inner_show.append(data[out][inner])
           outer_show.append(inner_show)
           
       
       spamwriter.writerows(outer_show)


def process_map(filename):
    data = {}
    for _, element in ET.iterparse(filename):
         key_type(element, data)
    #print ("len:",len(data))
    #print (data)
    #save_file(data,outputfile)

    print ("finished!")



def test():
    process_map(filename)
    #pprint.pprint(keys)

test()
