<?php
require "../include/lib.php";
$conn = db_connect();
$user_name = $_POST["name"];
$user_account = $_POST["account"];
$user_email = $_POST["email"];
$user_passwd = $_POST["passwd"];
$user_sex = $_POST["sex"];
$need = 'reg';
echo register($user_name,$user_account,$user_passwd,$user_sex,$user_email,$need).'<br>'; 
echo "<a href='../index.htm'>登录</a>&nbsp;&nbsp;<a href='../sub/register.php'>再次注册</a><br>";
?>






