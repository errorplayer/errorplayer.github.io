<?php
$receive_comments =  $_POST['my_comment'];
#echo $receive_comments.'<br>'; 
require "../include/lib.php";
$conn = db_connect();
$browse_name = $_COOKIE["user_name"];
$browse_account = $_COOKIE["user_account"];
echo $browse_name.' 正在浏览本页面<br>';
$author = '';
$article_title ='';
$sql_002 = 'select * from `article` where `id` = '.addslashes($_REQUEST["id"]);
$retval = mysqli_query($conn,$sql_002);
if ($retval){
    $num=mysqli_num_rows($retval); 
    for ($i=0; $i <$num ; $i++){ 
        $row=mysqli_fetch_assoc($retval);
        $title=$row['title'];
    	$content=$row['content'];
        $importtime=$row['importtime'];
    	$writer=$row['writer'];
        //$click=$row['click'];
        echo "<h3 align='center'>$title</h3>";
    	echo "<tr align='center'>作者： ".$writer."</tr><br>";
        echo "<td align='center'>正文： <br>".$content."</td><br>";
        $author = $writer;
        $article_title = $title;
        echo"<html>
                 <head>
                     <title>".$title."</title>
                     <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
      
                 </head>
             </html>";
     } 
}
else{
    echo '内容获取failed!';
}
echo '<br><br><br>';
//echo '准备抓取评论<br>';
//echo $receive_comments.'<br>';
if (!empty($receive_comments)){
    // echo '开始抓取评论<br>';
    $nowtime = date("Y-m-d H:i:s");
    $reg_sql = "insert into `comments` (`user`,`content`,`writer`,`title`,`timestamp`)";
    $reg_sql = $reg_sql." values ('".addslashes($browse_account)."','".addslashes($receive_comments)."','".addslashes($author)."','".addslashes($title)."','".addslashes($nowtime)."');";
    //echo $reg_sql.'<br>';
    $result = $conn->query($reg_sql) ;
}
$sql_003 = "select * from `comments` where `title` = '".addslashes($article_title)."' and `writer`='".addslashes($author)."';";
//echo $sql_003.'<br>';
$retval = mysqli_query($conn,$sql_003);
if ($retval){
   $num=mysqli_num_rows($retval); 
   for ($i=0; $i <$num ; $i++){ 
       $row=mysqli_fetch_assoc($retval);
       $name=Acc2Name($row['user']);
       $content=$row['content'];
       echo "<tr align='center'> ".$name." 说：</tr>";
       echo "<td align='center'> ".$content."</td><br>";
   } 
}
else{
   echo '还没有人评论，快来抢个沙发!<br>';
   echo $sql_003."<br>";
   echo "Error:" . $conn->error." <br>";
}
echo '<br><br><br>';
?>
<html>
<!--<form name='input' action="showarticle.php?id=<?php echo $_REQUEST['id']; ?>&a=<?php echo $_REQUEST['a']; ?>" method='post'>-->
<form name='input' action="showarticle_<?php echo $_REQUEST['id']; ?>" method='post'>
    ______reply_____   <input type='text' name='my_comment'>
<input type='submit' value='Submit'>
</form> 
<tr>
   <td rowspan="2"  bgcolor="#FF9999">
   <td bgcolor="#CCFFCC">
           <!--<a href="articlelist.php?a=<?php echo $_REQUEST['a']; ?>">返回文章列表</a> -->
        <a href="articlelist">返回文章列表</a>
   </td>
</tr>
</html>




