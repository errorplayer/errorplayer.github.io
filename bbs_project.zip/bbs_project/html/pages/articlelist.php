<html>
<head>
      <title>帖子列表</title>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
</html>
<?php
   require "../include/lib.php";
   $conn = db_connect();
   #var_dump($_COOKIE);
   $sql_002 = 'select * from article;';
   echo "<h3 align='center'>所有帖子</h3>";
   #$author = $_REQUEST["a"];
   $browse_name = $_COOKIE["user_name"];
   $browse_account = $_COOKIE["user_account"];
   # if (!isset($_COOKIE["username"]))  echo 'balabala<br>';
   echo '检测到 '.$browse_name.' 正在浏览...<br>';
   #echo "<h5 align='center'><a href='../sub/writetopic.php?a=$author'>我要发帖</a></h5>";
   echo "<h5 align='center'><a href='../sub/writing'>我要发帖</a></h5>";#../sub/writetopic.php'>我要发帖</a></h5>";
   $retval = mysqli_query($conn,$sql_002);
   if ($retval){
      $num=mysqli_num_rows($retval); 
      for ($i=0; $i <$num ; $i++){ 
          $row=mysqli_fetch_assoc($retval);
          $title=$row['title'];
    	  $content=$row['content'];
          $importtime=$row['importtime'];
    	  $writer=$row['writer'];
          $click=$row['click'];
          $id= $row['id'];
          #$target_url = 'showarticle.php?id='.$id;#.'&a='.$author;
          $target_url = 'showarticle_'.$id;#.'&a='.$author;
          echo "<table width='700' border='0' align='center' height='18'>
                            <tr> 
                               <td bgcolor='#CCFFCC'   align='left'>
                                     <a href='$target_url'>$title</a>
                               </td>
                                <td bgcolor='#CCFFCC'  align='right'>
                                             $importtime
                                </td>
                            </tr>
                    </table><br>";
      } 
   }
   else {
       echo 'failed!';
   }
   echo "<table width='300' border='0' align='center' height='18'>
                            <tr> 
                               <td bgcolor='#DDDDDD'   align='center'>
                                    <a href='../index.htm'>切换帐号 </a>
                               </td>
                                
                            </tr>
                    </table><br>";
?>






