<html>
<head>
    <title>写个帖子</title>
    <meta http-equiv="Content-Type" content="text/html"; charset="utf-8">
</head>
<body bgcolor="#2e8b57">
      <table width="454" border="0" align="center" height="200">
          <form method="post" action="jump_store_article" name="store"
                onsubmit="return CheckValid(document.store);">
                <input type="hidden" name="a"  value="<?php print $_REQUEST["a"] ?>">
                
                <tr bgcolor="#C8E8B0">
                    <td height="18">
                        <p>帖子标题：
                        <input type="text" name="blog_title" maxlength="90" value="<?php print $info_self["blog_title"];?>">
                        </p>
                    </td>
                </tr>
              <tr bgcolor="#C8E8B0">
                  <td height="31">
                     <p>帖子内容：</p>
                          
                                 <textarea name="blog_content" cols='130' rows="20" warp="virtual"></textarea>
                  </td>
              </tr>
              <tr valign="top" align="center" bgcolor="#FFCCCC">
                  <td height="36" width="448">
                      <input type="submit" name="subreg" value="确认并提交">
                      <input type="reset" name="reset" value="重填">
                  </td>
              </tr>

          </form>
      </table>
       <p>&nbsp;</p>
     <script language="JavaScript">
        function CheckValid(obj) {
            if (obj.blog_title.value == ""){
                alert("帖子标题不能为空！");
                obj.blog_title.focus();
                return false;
            }
            if (obj.blog_content.value == "" ){
                alert("帖子内容不能为空！");
                obj.blog_content.focus();
                return false;
            }
        }
    </script>
</body>
</html>
