<html>
<head>
    <title>新用户注册</title>
    <meta http-equiv="Content-Type" content="text/html"; charset="utf-8">
    <script language="JavaScript">
        function CheckValid(obj) {
          if (obj.name.value == "")
            {
                alert("请输入正确的用户名！");
                obj.name.focus();
                return false;
            }
         if (obj.account.value == "")
            {
                alert("请输入登录帐号！");
                obj.account.focus();
                return false;
            }
            if (obj.passwd.value == "" || obj.passwd.value != obj.repasswd.value )
            {
                alert("请检查您输入的密码！");
                obj.passwd.focus();
                return false;
            }
            if (obj.email.value == "")
            {
                alert("请检查您输入的email！");
                obj.email.focus();
                return false;
            }

        }
    </script>
</head>
<body bgcolor="#2e8b57">
      <table width="451" border="0"  height="112" align="center">
          <tr bordercolor="#FFFFFF" bgcolor="FFCCCC">
              <td>欢迎您加入论坛。会员须知：</td>
          </tr>
          <tr bgcolor="FFCCCC">
              <td>1.本论坛的设计目的是为了增加同学们技术交流的机会，活跃同学课余时间的学术氛围；</td>
          </tr>
          <tr bgcolor="FFCCCC">
              <td>2.本着会员自由、知识共享的原则，凡在本论坛发表的文章均可自由转载，但必须注明作者并声明出自本论坛；</td>
          </tr>
          <tr bgcolor="FFCCCC">
              <td>3.凡本论坛用户均有义务维护本论坛的纯洁；</td>
          </tr>
          <tr bgcolor="FFCCCC">
              <td>4.祝您能在这里找到想要的东西，同时也希望您不吝赐教，让更过的人有机会共享知识。</td>
          </tr>
      </table>
      <table width="454" border="0" align="center" height="200">
          <form method="post" action="../pages/showregisterinfo.php" name="register"
                onsubmit="return CheckValid(document.register);">
                <input type="hidden" name="need"  value="<?php print $need; ?>">
                <input type="hidden" name="cryptname"  value="<?php print $cryptname; ?>">
                <tr bgcolor="#C8E8B0">
                    <td height="18">
                        <p>用户昵称：
                        <input type="text" name="name" maxlength="20" value="<?php print $info_self["name"];?>">
                            *
                        </p>
                    </td>
                </tr>
                 <tr bgcolor="#C8E8B0">
                    <td height="18">
                        <p>登录帐号：
                        <input type="text" name="account" maxlength="20" value="<?php print $info_self["account"];?>">
                            *
                        </p>
                    </td>
                </tr>
              <tr bgcolor="#C8E8B0">
                  <td height="31">
                      <p>用户密码：
                          <input type="password" name="passwd" maxlength="20" value="<?php print $info_self["passwd"];?>">
                      </p>
                  </td>
              </tr>
              <tr bgcolor="#C8E8B0">
                  <td height="31">
                      <p>确认密码：
                          <input type="password" name="repasswd" maxlength="20" value="<?php print $info_self["passwd"];?>">
                      </p>
                  </td>
              </tr>
              <tr bgcolor="#C8E8B0">
                  <td colspan="2">性别：
                      <input type="radio" name="sex"  value="boy" <?php if($sex=="boy"||$need=="reg") print"checked";?>>
                      男 &nbsp;&nbsp;
                      <input type="radio" name="sex"  value="girl" <?php if($sex=="girl") print"checked";?>>
                      女

                  </td>
              </tr>
              <tr bgcolor="#C8E8B0">
                  <td height="32">
                      <p>email: &nbsp;&nbsp;&nbsp;&nbsp;
                          <input type="text" name="email"  value="<?php print $info_self["email"];?>">*
                      </p>
                  </td>
              </tr>
              <tr valign="top" align="center" bgcolor="#FFCCCC">
                  <td height="36" width="448">
                      <input type="submit" name="subreg" value="确认并提交">
                      <input type="reset" name="reset" value="重填">
                  </td>
              </tr>

          </form>
      </table>
       <p>&nbsp;</p>
</body>
</html>

