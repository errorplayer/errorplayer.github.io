<?php
require "../include/lib.php";
$conn = db_connect();
$title = $_POST["blog_title"];
$content = $_POST["blog_content"];
#$author = $_REQUEST["a"];
$writer_account =$_COOKIE["user_account"];
echo writeArticle($title,$content,$writer_account); 
echo "<a href='/pages/articlelist'>返回列表</a><br>";
?>





