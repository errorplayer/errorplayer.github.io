<?php

$host = 'localhost';
$user = 'forum_admin';
$password = '123456';
$db_name = 'forum';

function db_connect()
{
    global $host,$user,$password,$db_name;
    $conn = new mysqli($host, $user, $password, $db_name);
// 检测连接
    if ($conn->connect_error) {
        die("连接失败: " . $conn->connect_error);
        //echo "连接失败"."<br>";
    }
    else{
        //echo "服务器连接成功"."<br>";
    }
    return $conn;
}

function db_close()
{
    global $conn;
    $conn->close();
}

function db_error()
{
    echo "数据库错误：";
    echo mysqli_erron(); //error code
    //echo mysqli_error()."<br>";   //错误信息不能输出给用户看到，可放入服务器log
    echo "请联系系统管理员";
    echo "<a href=mailto:linzeyang@sc-edu.com>发信给系统管理员</a>";
    exit;

}

function check($account,$passwd)
{
       global $conn;
       $sql = "select * from `user` where `account` = '".addslashes($account)."'and `passwd` = '".addslashes($passwd)."';";
       $result = mysqli_query($conn,$sql);
       if ($result){
           $self_info = mysqli_fetch_array($result);
           //return $self_info;
              if($self_info){
                 return "loginAccept";
              }
              else{
                 return "loginReject";
              }
       }
}

function Acc2Name($account)
{
    global $conn;
    $sql = "select * from `user` where `account` = '".addslashes($account)."';";
    $retval = mysqli_query($conn,$sql);
    if ($retval){

         $num=mysqli_num_rows($retval); 
         $row=mysqli_fetch_assoc($retval);
         $name=$row['name'];
    	 return $name;
    }
    else{
        return "illegal user";
    }
}
function string_dowith($str)
{
    $str = trim($str);
    $str = htmlspecialchars($str);  //transform to HTML standard
    return $str;
}

function test_dowith($str)
{
    $str = htmlspecialchars($str);
    $str = ereg_replace("\n","<br>",$str);
    $str = nl2br($str);
    $str = ereg_replace(" ","&nbsp",$str);
    return $str;
}
function register($name,$account,$passwd,$sex,$email,$need)
{
   global $conn;
   $msg = "";
   //echo '1<br>';
   if ($name != "" && $passwd != ""&& $account != ""){
       //echo '11<br>';
       $name = string_dowith($name);
       #$account = string_dowith($account);  
       $sql = "select `id` from `user` where `account`='".addslashes($account)."'";
       //echo $sql.'<br>';
       if ($conn->query($sql) === TRUE){
           $msg = "该帐号已经存在！请换一个帐号。";
           return $msg;
       } 
       $sql = "select `id` from `user` where `name`='".addslashes($name)."'";
       if ($conn->query($sql) === TRUE){
           $msg = "该用户昵称已经存在！请换一个昵称。";
           return $msg;
       } 
       else{
          //echo "Error: " . $sql . "<br>" . $conn->error;
          $nowtime = date("Y-m-d H:i:s");
          $reg_sql = "insert into `user` (`name`,`account`,`passwd`,`sex`,`email`,`time_register`)";
          $reg_sql = $reg_sql."values ('".addslashes($name)."','".addslashes($account)."','".addslashes($passwd)."','".addslashes($sex)."','".addslashes($email)."','".addslashes($nowtime)."')";
          //echo $reg_sql.'<br>';
          if ($conn->query($reg_sql) === TRUE) {
              $msg = "恭喜！你已经注册成功。";
          } 
          else{
              //echo "Error: " . $reg_sql . "<br>" . $conn->error;
              $msg =  $name.' 已经被注册了，请换一个用户名吧';
          }
       }
   }
   return $msg;
}
function writeArticle($title,$content,$writer_account)
{
    global $conn;
    $msg = "";
    $sql = "select * from `user` where `account`='".addslashes($writer_account)."'";
    //echo $sql;
    $retval = mysqli_query($conn,$sql);
    $num=mysqli_num_rows($retval); 
    $content=test_dowith($content);
    if ($num > 0){
       $nowtime = date("Y-m-d H:i:s");
       $reg_sql = "insert into `article` (`title`,`content`,`writer`,`click`,`importtime`)";
       $reg_sql = $reg_sql."values ('".addslashes($title)."','".addslashes($content)."','".addslashes($writer_account)."',10,'".addslashes($nowtime)."')";
       if ($conn->query($reg_sql) === TRUE) {
           $msg = "恭喜！帖子发布成功。<br>";
       } 
    }
    else{
        $msg = ' 请使用你自己的用户名发表言论！<br>';
        //echo $msg;
    }
    return $msg;
}
function article_style()
{
    $outstr="
    <style>
        td {font-family: 宋体,arial; font-size:9pt}
        body {font-family: 宋体,arial; font-size:9pt}
        table {font-family: 宋体,arial; font-size:9pt}
        .c {font-family: 宋体,arial; font-size:11pt}
        .e {font-family: 宋体,arial; font-size:9pt; font-weight: bold}
        a:link {font-size:9pt; text-decoration:none;}
        a:visited {font-size:9pt; text-decoration:none;}
        a:hover {font-size:9pt; text-decoration:underline;}
        A.forum():link {color:#3333cc; text-decoration:none;font-size:9pt; }
        A.forum():visited {color:#800080; text-decoration:none;font-size:9pt; }
        A.forum():hover {color:#9999ff; text-decoration:underline;font-size:9pt; }
    </style>
    ";
    echo $outstr;
}
?>
