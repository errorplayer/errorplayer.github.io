<?php

echo '错误信息';
if ($error == ''){
    echo '未知错误！';
}
else{
    echo $error.'<br>';
}
echo "请点击<a href='JavaScript:history.go(-1)'>返回</a>";




?>
