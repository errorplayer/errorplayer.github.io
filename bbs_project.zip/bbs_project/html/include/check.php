<?php
$need = $_REQUEST["need"];
require "lib.php";
$account = $_REQUEST["account"];
$passwd = $_REQUEST["passwd"];
#die($need);
$conn = db_connect();

if(!empty($need))
{
    if ($need == "login"){
         //echo '捕获登录动作<br>';
         //echo $name.'%%'.$passwd.'<br>';
         
        $self_info = check($account,$passwd);
           //  echo  $self_info.'<br>';
          
        if($self_info=="loginAccept"){
               setcookie("user_name",Acc2Name($account),time()+3600*1,'/');
	       setcookie("user_account",$account,time()+3600*1,'/');
               header("location:../pages/articlelist");#?a=$name");
               echo '密码对了';
        }
        elseif($self_info=="loginReject"){  
             echo '密码错了兄弟<br>' ;
             echo "<a href='../index.htm'>返回登录</a><br>";
             die(' ' );
        }
    }
    else{
       die('未捕获登录');
    }
   
}
if (!empty($error)){
    include "error.php";
    exit;
}

?>
